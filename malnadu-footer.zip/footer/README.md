# Malnadu footer drop-in

Files
- components/ui/halftone-wordmark-footer.tsx  (paste the component from the 21st.dev prompt unchanged)
- components/malnadu-footer.tsx               (this wrapper, the thing you actually render)
- public/assets/kolam-diamond.svg             (used in the top strip)
- public/assets/kolam-loop.svg, kolam-spine.svg  (cleaned, transparent, cream, optional)

Replace the old <footer id="visit-us" class="bwf"> block with <MalnaduFooter />.
