# FINCORE Consultancy Services — Website Design Document

**Version:** 1.0 | **Design direction:** Premium, clear, trustworthy, modern Indian consultancy

## 1. Design principles
1. **Trust first:** restrained effects, strong hierarchy, transparent service descriptions.
2. **Clarity over decoration:** each section helps visitors understand services or take the next step.
3. **Premium but approachable:** generous whitespace, crisp typography, subtle borders.
4. **Mobile-first:** compact navigation, readable type, full-width cards and forms.
5. **Honest conversion:** no fake testimonials, invented credentials, or unverified claims.

## 2. Design tokens
- Royal Blue: `#163E8C` — primary buttons, links, accents.
- Deep Royal Blue: `#0B2458` — hero, dark sections, gradients.
- Black: `#080B12` — dark surfaces and text.
- White: `#FFFFFF` — main canvas and reversed text.
- Light Blue: `#EAF1FF` — soft feature backgrounds.
- Light Gray: `#F5F7FA` — alternating sections.
- Secondary text: `#687386`.
- Border: `#E2E8F0`.
- Error: `#B42318`; success: `#18794E`.

### Typography
Use Inter, Manrope, or Plus Jakarta Sans. Suggested sizes: hero 48–64 px desktop / 32–40 px mobile; section headings 32–40 px desktop / 26–32 px mobile; body 16–18 px with 1.5–1.7 line-height; labels 13–14 px.

### Layout
Content max width approximately 1200 px. Desktop gutters 32–48 px; mobile gutters 20–24 px. Spacing scale 4, 8, 12, 16, 24, 32, 48, 64, 88 px. Cards use 16–20 px radius; inputs 10–12 px radius.

## 3. Sitemap
Home → About → Services → Service detail → Who We Serve → How It Works → FAQs → Contact / Consultation. Footer: Privacy Policy, Terms & Conditions, Disclaimer.

## 4. Homepage wireframe
1. **Header:** wordmark, nav links, consultation CTA.
2. **Hero:** deep-blue/black background; headline, supporting copy, two CTAs, abstract finance visual.
3. **Service highlights:** four short capability points; no invented statistics.
4. **Services:** six service-category cards; 3 columns desktop, 2 tablet, 1 mobile.
5. **About / approach:** two-column story and visual.
6. **Who we serve:** cards for individuals, freelancers, startups, SMEs, partnerships, companies.
7. **How it works:** four-step process.
8. **FAQs:** accessible accordion.
9. **Consultation:** intro plus enquiry form.
10. **Footer:** brand, navigation, service links, verified contact details, legal links.

## 5. Component specifications
### Header
Approx. 76–84 px desktop; white surface and fine border. Text-based wordmark with geometric finance-inspired mark. Mobile menu must be keyboard accessible and close after navigation.

### Hero
Dark royal-blue-to-black field, subtle abstract geometry, clear H1 and short copy. Primary CTA “Explore our services”; secondary CTA “Book a consultation”. Avoid fake dashboard metrics.

### Service card
White/light surface, 1 px border, consistent height, icon, category label, title, short description, text link. Hover: slight lift and blue border; visible focus ring.

### Consultation form
Visible labels for name, phone, email, client type, service, optional business name, requirement, preferred contact method, and consent. Inline errors; server-confirmed success only. Add server-side validation and anti-spam before launch.

### Footer
Deep-blue/black surface, high-contrast text, four columns desktop and stacked mobile. Use owner-provided contact details only.

## 6. Responsive behavior
- **Desktop ≥1024 px:** split hero, 3-column service grid, multi-column footer.
- **Tablet 768–1023 px:** 2-column cards, reduced hero scale, stacked contact layout if needed.
- **Mobile <768 px:** menu toggle, single-column cards, wrapped/staked CTAs, full-width fields, no horizontal scrolling.
- Respect `prefers-reduced-motion`.

## 7. Interaction and motion
Short 150–220 ms transitions for buttons/cards; FAQ disclosure; form loading/error/success states. Smooth anchor scrolling only when reduced motion is not enabled. Avoid layout-shifting animations.

## 8. Accessibility
Use semantic `header`, `nav`, `main`, `section`, and `footer`. One descriptive H1 per page. Associate labels with form fields. Ensure keyboard reachability, visible focus, contrast, meaningful alt text, and reduced-motion support. Do not use color alone to communicate errors or status.

## 9. Technical architecture
**Included prototype:** semantic HTML, CSS, and vanilla JavaScript; no framework build step required.

**Production option:** Next.js App Router + TypeScript, Tailwind CSS, React Hook Form + Zod, and Supabase or equivalent only if enquiry persistence is needed. Add a server-side endpoint, rate limiting, spam protection, server validation, secure email delivery, and environment variables. Never expose secrets in browser code.

## 10. Privacy and data
Collect the minimum information required for a callback. Do not request tax IDs, bank credentials, passwords, or document uploads in the initial public form. Publish a reviewed privacy notice describing purpose, access, retention, and contact method.

## 11. SEO and deployment
Use unique titles/descriptions, social metadata, canonical URLs, sitemap, robots configuration, and accurate structured data only after business details are verified. Compress images, minimize scripts, test links, keyboard access, forms, performance, and production build before launch.

## 12. Launch checklist
- [ ] Replace contact and WhatsApp placeholders.
- [ ] Verify service scope and professional qualifications.
- [ ] Review Privacy Policy, Terms, and Disclaimer.
- [ ] Connect and test real enquiry backend.
- [ ] Configure server-side validation, spam controls, and notifications.
- [ ] Test responsive breakpoints and accessibility.
- [ ] Check SEO, performance, and security.
- [ ] Confirm no fake reviews, credentials, or guaranteed outcomes.
