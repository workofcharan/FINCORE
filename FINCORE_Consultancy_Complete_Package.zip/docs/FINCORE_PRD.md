# FINCORE Consultancy Services — Product Requirements Document (PRD)

**Version:** 1.0 | **Status:** Initial specification | **Market:** India

## 1. Product summary
FINCORE is a professional consultancy website explaining financial, taxation, business-registration, accounting, payroll-compliance, and licensing support. Its primary purpose is to build trust, help visitors understand services, and convert suitable visitors into qualified enquiries.

The website must not imply guaranteed registrations, approvals, refunds, or tax savings. Qualifications, years of experience, client counts, awards, office locations, and other claims must be published only after the business owner verifies them.

## 2. Problem statement
Individuals and businesses may be unsure which registrations, filings, or compliance tasks apply to them. They need a clear place to explore service categories, understand the general process, and contact the consultancy without searching fragmented sources.

## 3. Goals and success measures
**Goals**
- Present FINCORE as a credible, modern consultancy brand.
- Make the service portfolio easy to scan.
- Increase useful enquiries through an accessible contact flow.
- Support mobile-first visitors.
- Provide a foundation that can grow into dedicated service pages and enquiry management.

**Suggested measures (establish baseline after launch):** qualified enquiries/month, form completion rate, consultation CTA click-through rate, service-page engagement, response time, mobile performance and accessibility results.

## 4. Target audiences
1. Individuals and salaried professionals seeking income-tax return support.
2. Freelancers and independent consultants.
3. Startups and entrepreneurs setting up a business.
4. Proprietors, traders, and small businesses needing GST or licensing assistance.
5. Partnership firms, LLPs, and companies requiring registration or ongoing compliance.
6. Businesses seeking accounting, bookkeeping, payroll, PF, or ESI support.
7. Food businesses seeking guidance on applicable FSSAI requirements.

## 5. Scope
### Initial release
- Responsive homepage and service discovery.
- Service categories and descriptions.
- About/approach and “Who We Serve” sections.
- Four-step process section.
- FAQ accordion.
- Consultation enquiry form with client-side validation.
- Contact detail placeholders and WhatsApp integration placeholder.
- Privacy, Terms, and Disclaimer page/section placeholders.
- SEO metadata, accessible semantics, and deployment notes.
- Royal Blue + Deep Blue + Black + White visual system.

### Later / optional release
- Dedicated pages for each service.
- Admin dashboard for enquiries.
- Secure email notifications and database persistence.
- Appointment scheduling and CMS.
- Analytics and conversion tracking with appropriate consent.
- Multilingual content, including Telugu, if requested.

### Out of scope unless separately approved
- Automated tax filing or government-portal submissions.
- Automated legal, tax, or financial advice.
- Public upload/storage of sensitive identity or tax documents.
- Payment collection.
- Claims of official affiliation or guaranteed government approvals.

## 6. Service inventory from the business notes
### Taxation and financial compliance
- Income Tax Return (ITR) filing support for individuals and eligible entities.
- GST registration and GST return filing.
- TDS and TCS compliance support.
- Professional Tax (PT) compliance where applicable.
- PF and ESI registration/filing support where applicable.
- Related financial and statutory filing assistance, subject to confirmed scope.

### Business and company registration
- Company incorporation.
- Private Limited Company registration assistance.
- LLP registration.
- Partnership-firm registration.
- Proprietorship registration assistance.
- Registration documentation and ongoing statutory compliance assistance.

### Accounting and bookkeeping
- Bookkeeping and accounting records.
- Financial record maintenance.
- Account reconciliation.
- Financial statements and reporting support.
- Business expense tracking and documentation.

### Licenses and approvals
- Trade-license assistance.
- Labour-license assistance where applicable.
- Food-business license / FSSAI registration assistance.
- Other relevant business licenses and registrations, subject to business activity and location.

### Payroll and employee compliance
- Payroll documentation.
- PF and ESI compliance support where applicable.
- Employee-related statutory filing coordination.

### Business consultancy
- Business setup guidance.
- Documentation assistance.
- Compliance planning.
- Registration and filing coordination.
- Ongoing compliance support.

Service names and scope must be reviewed by the business owner and qualified professionals before publication. Requirements vary by entity, state, activity, eligibility, and current rules.

## 7. Information architecture / sitemap
- Home
- About FINCORE
- Services
  - Taxation & Financial Compliance
  - Business & Company Registration
  - Accounting & Bookkeeping
  - Licenses & Business Approvals
  - Payroll & Employee Compliance
  - Business Consultancy
- Who We Serve
- How It Works
- FAQs
- Contact / Book a Consultation
- Privacy Policy
- Terms & Conditions
- Disclaimer

## 8. Functional requirements
**FR-01 Navigation:** consistent navigation, active/hover states, prominent consultation CTA, accessible mobile menu.

**FR-02 Service discovery:** group services into labelled categories; each card has title, short description, and enquiry action.

**FR-03 Consultation form:** collect name, phone, email, client type, service category, optional business name, short requirement, preferred contact method, and consent. Validate required fields and show clear error/success states. Production submissions require a secure backend and genuine server-confirmed success.

**FR-04 Contact links:** phone, email, and WhatsApp must use owner-provided details; placeholders must be replaced before launch.

**FR-05 FAQ:** expandable/collapsible with pointer and keyboard.

**FR-06 Responsive design:** no horizontal overflow at common mobile, tablet, laptop, and desktop widths.

**FR-07 SEO:** meaningful titles, descriptions, semantic headings, clean URLs, social metadata, and descriptive image alt text.

**FR-08 Trust/legal:** provide privacy, terms, and disclaimer content for review. Legal text must be reviewed for the actual business.

**FR-09 Feedback:** buttons and forms provide meaningful states; no dead controls or false delivery claims.

## 9. Non-functional requirements
- **Accessibility:** semantic HTML, keyboard access, visible focus, adequate contrast, labels, reduced-motion support.
- **Performance:** optimized assets, limited JavaScript, no unnecessary dependencies; target good Core Web Vitals.
- **Security:** HTTPS, server-side validation, secrets in environment variables, spam protection, data minimization, access controls for stored enquiries.
- **Maintainability:** reusable design tokens, organized components, separation of content/styles/behavior.
- **Privacy:** collect only necessary information and document access and retention practices before storage.

## 10. User journeys
**A. Individual tax enquiry:** Home → Taxation service card → review overview → select “Income Tax Return Filing” in form → submit → receive confirmation only after backend acceptance.

**B. New business setup:** Home → Business Registration → review entity types → submit business enquiry → team confirms suitability and documents.

**C. Compliance support:** Home → Payroll & Employee Compliance → review PF/ESI support → submit enquiry → team confirms applicable obligations and scope.

**D. License enquiry:** Home → Licenses & Approvals → describe business activity/location → team clarifies relevant license and eligibility.

## 11. Content requirements
Use plain English and avoid unnecessary legal jargon. Explain that requirements vary by entity, state, business activity, eligibility, and current rules. Avoid fixed fees or guaranteed timelines unless confirmed and maintained by the business.

## 12. Acceptance criteria
- Navigation links lead to valid sections/pages.
- No horizontal overflow at 360, 768, 1024, and wide desktop widths.
- All form controls have visible labels and useful validation.
- Consent is required before submission.
- FAQ works by keyboard and pointer.
- Buttons have visible hover/focus states.
- No invented contact details, testimonials, ratings, awards, credentials, or statistics.
- Production form integration does not claim delivery before server confirmation.
- Privacy, Terms, and Disclaimer pages/sections exist and are marked for review.
- Setup and deployment steps are documented.

## 13. Risks and dependencies
Owner must provide actual phone, email, address, operating hours, and official WhatsApp number. Owner must verify services, credentials, and professional scope. A backend, email provider, privacy notice, and spam controls are required for production enquiry handling. Regulatory content must be reviewed periodically.

## 14. Release plan
1. Confirm brand assets and contact information.
2. Verify service scope and legal language.
3. Approve responsive design.
4. Connect secure enquiry backend and notifications.
5. Test accessibility, mobile layouts, and error states.
6. Run SEO, performance, and security checks.
7. Deploy and monitor enquiry quality.
