# FINCORE Consultancy Services — Website Package

## Included
- `website/index.html` — responsive single-page website prototype.
- `website/styles.css` — Royal Blue / Deep Blue / Black / White design system and responsive styles.
- `website/script.js` — mobile navigation, service preselection, accessible client-side form validation.
- `docs/FINCORE_PRD.md` and `docs/FINCORE_Design_Document.md` — editable source documents.
- `docs/FINCORE_PRD.pdf` and `docs/FINCORE_Design_Document.pdf` — PDF versions.
- `design-assets/FINCORE_website_design_board.png` — visual design reference board, if included.

## Run locally
1. Extract the package.
2. Open `website/index.html` in a browser, or run a local static server from the `website` folder:
   - Python: `python -m http.server 8000`
   - Then visit `http://localhost:8000`.
3. Replace the contact placeholders only with verified business details.

## Important prototype limitation
The form currently validates locally in the browser only. It does not send, email, or store enquiries. Before production, connect a secure backend with server-side validation, spam protection/rate limiting, appropriate privacy notice, access controls, and a real success response only after the server confirms receipt.

## Deployment
This static website can be deployed by uploading the `website` folder to static hosting, or importing the folder/repository into a hosting provider that supports static sites. For a Git-based workflow:
1. Put the `website` files in a repository.
2. Push the repository to your Git provider.
3. Create a static site project in your hosting provider and select the repository/root directory.
4. Set the output/publish directory to `website` if the repository root contains docs as well.
5. Deploy and test all anchors, mobile menu, form validation, metadata, and legal sections.

## Before launch
- Replace contact placeholders.
- Verify actual service scope and professional credentials.
- Review privacy, terms, and disclaimer wording for the real business.
- Connect a secure form backend and test delivery.
- Check accessibility, performance, SEO, and browser compatibility.
