const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector("#primary-nav");
if (menuButton && nav) {
  menuButton.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("is-open");
    menuButton.setAttribute("aria-expanded", String(isOpen));
    menuButton.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  });
  nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    nav.classList.remove("is-open");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Open navigation");
  }));
}
document.querySelectorAll("[data-service]").forEach(link => {
  link.addEventListener("click", () => {
    const service = document.querySelector("#service");
    if (service) service.value = link.dataset.service;
  });
});
document.querySelector("#year").textContent = new Date().getFullYear();

const form = document.querySelector("#enquiry-form");
const status = document.querySelector("#form-status");
const fields = ["full-name","phone","email","client-type","service","requirement"];
function setError(input, message) {
  input.setAttribute("aria-invalid", message ? "true" : "false");
  const holder = input.closest(".field")?.querySelector(".field-error");
  if (holder) holder.textContent = message || "";
}
function validate(input) {
  const value = input.value.trim();
  if (input.required && !value) return "This field is required.";
  if (input.id === "email" && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return "Enter a valid email address.";
  if (input.id === "phone" && value && value.replace(/\D/g,"").length < 8) return "Enter a valid phone number.";
  return "";
}
if (form) {
  form.querySelectorAll("input,select,textarea").forEach(input => {
    input.addEventListener("blur", () => { if (input.id !== "consent" && input.name) setError(input, validate(input)); });
    input.addEventListener("input", () => { if (input.getAttribute("aria-invalid") === "true") setError(input, validate(input)); });
  });
  form.addEventListener("submit", event => {
    event.preventDefault();
    let valid = true;
    fields.forEach(id => {
      const input = document.getElementById(id);
      const message = validate(input);
      setError(input, message);
      if (message) valid = false;
    });
    const consent = document.getElementById("consent");
    const consentError = document.querySelector(".consent-error");
    consentError.textContent = consent.checked ? "" : "Please provide consent before continuing.";
    if (!consent.checked) valid = false;
    status.className = "form-status";
    if (!valid) {
      status.textContent = "Please review the highlighted fields.";
      status.classList.add("error");
      const firstInvalid = form.querySelector('[aria-invalid="true"]');
      if (firstInvalid) firstInvalid.focus();
      return;
    }
    // This prototype intentionally does not transmit or persist personal data.
    status.textContent = "Validation passed. This demo does not send your enquiry; connect a secure backend before launch.";
    status.classList.remove("error");
  });
}
